---
name: Voga Productions Cloudinary Assets
description: Which Cloudinary assets actually work (200 vs 404) and correct URL patterns
---

## Working Videos (200 ✅)
- `https://res.cloudinary.com/dzkhuidmn/video/upload/q_auto,f_mp4/v1781399019/1E9A6D30-AD90-414D-80BE-1338FEE9DBFD_2_0_a_bqt4qa.mp4`
- `https://res.cloudinary.com/dzkhuidmn/video/upload/q_auto,f_mp4/v1781399174/173B33A2-63DB-43C9-8959-8D2EC91B018F_2_0_a_ncdlcm.mp4`

## 404 Videos (DO NOT USE)
- v1781399048/0887D14B..., v1781399052/72D36E26..., v1781399046/1BFEFDC4...,
  v1781399040/9BE8BA43..., v1781399043/A6A3A91C..., v1781399022/9F1DE9B1..., v1781399038/8BC83A6D...

## Working Partner Logos (200 ✅)
- `v1781411219/new_logo_rb0j3q.png` — Orientica
- `v1781411289/IMG_4266_gaap0b.jpg` — Nayaat

## 404 Partner Logos (images hidden via onError, text-only fallback)
- bright_interior_logo_final_naqxyw.png, goltens-logo-vector_efdptb.png,
  ELITE_Logo-1_h2lftj.webp, carat_logo_lf5ikr.png

## Critical URL Rule
**Why:** Cloudinary `f_mp4` transform in path does NOT fix browser refusal of `.mov` extension.
**Fix:** Always change file extension to `.mp4` — browsers check extension first.
Pattern: `https://res.cloudinary.com/dzkhuidmn/video/upload/q_auto,f_mp4/v{VERSION}/{ID}.mp4`
