import React, { useState, useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    num: '01',
    title: "Video Production",
    desc: "Cinematic Storytelling and Brand Films, Corporate and Business Videos, Lifestyle and Product Videos, Luxury Property and Hospitality Videos, Automotive Cinematics and Commercials, Documentary and Event Coverage."
  },
  {
    num: '02',
    title: "Post-Production",
    desc: "Professional Video Editing and Assembly, Color Grading and Cinematic LUT Application, Visual Effects (VFX) and Motion Graphics, Sound Design and Audio Engineering, Subtitling, Captioning and Localisation, Format Optimisation for Multi-Platform Delivery."
  },
  {
    num: '03',
    title: "Creative Direction",
    desc: "Brand Strategy and Visual Identity Consultation, Storyboarding and Pre-Production Planning, Script Writing and Narrative Development, Location Scouting and Set Design, Talent Coordination and Art Direction."
  },
  {
    num: '04',
    title: "Photography",
    desc: "Commercial and Product Photography, Architectural and Interior Photography, Lifestyle and Portrait Sessions, Event and Corporate Photography, Aerial and Drone Photography, Retouching and Post-Processing."
  },
  {
    num: '05',
    title: "Social Media Content",
    desc: "Short-Form Video Content for Instagram, TikTok, YouTube, Reels, Shorts, Stories and Platform-Specific Formats, Branded Content Campaigns, Influencer and Collaboration Shoots, Content Strategy and Calendar Planning."
  },
];

export default function ServicesSection() {
  const [open, setOpen] = useState<number | null>(null);
  const headRef = useRef<HTMLHeadingElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.fromTo(labelRef.current,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: headRef.current, start: 'top 80%' } }
    );
    gsap.fromTo(headRef.current,
      { opacity: 0, clipPath: 'inset(0 0 100% 0)' },
      { opacity: 1, clipPath: 'inset(0 0 0% 0)', duration: 1.1, ease: 'power3.out', delay: 0.1, scrollTrigger: { trigger: headRef.current, start: 'top 80%' } }
    );
    if (listRef.current) {
      const rows = listRef.current.querySelectorAll('.svc-row');
      gsap.fromTo(rows,
        { opacity: 0, y: 24 },
        { opacity: 1, y: 0, duration: 0.7, stagger: 0.08, ease: 'power3.out', scrollTrigger: { trigger: listRef.current, start: 'top 85%' } }
      );
    }
  }, []);

  return (
    <section id="services" style={{ padding: '100px 0', background: '#0a0a0a' }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 40px' }}>
        <div style={{ marginBottom: '64px' }}>
          <span ref={labelRef} style={{ display: 'block', fontSize: '1rem', letterSpacing: '0.025rem', textTransform: 'uppercase', color: '#c9a84c', marginBottom: '1rem', fontFamily: "'Overused Grotesk', Arial, sans-serif", fontWeight: 500 }}>
            Our Solutions
          </span>
          <h2
            ref={headRef}
            style={{
              fontSize: 'clamp(3rem, 8vw, 10rem)',
              fontWeight: 600,
              lineHeight: 1,
              letterSpacing: '0.1rem',
              textTransform: 'uppercase',
              fontFamily: "'Overused Grotesk', Arial, sans-serif",
              background: 'linear-gradient(180deg, #ffffff 40%, #555 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Video<br />Services
          </h2>
        </div>

        <div ref={listRef} style={{ borderTop: '1px solid rgba(240,234,214,0.1)' }}>
          {services.map((svc, i) => (
            <div key={i} className="svc-row" style={{ borderBottom: '1px solid rgba(240,234,214,0.1)' }}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '28px 0',
                  background: 'none',
                  border: 'none',
                  textAlign: 'left',
                  gap: '24px',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '28px', flex: 1 }}>
                  <span style={{ fontSize: '12px', color: 'rgba(201,168,76,0.6)', fontFamily: "'Overused Grotesk', Arial, sans-serif", letterSpacing: '0.1em', flexShrink: 0, minWidth: '28px' }}>
                    {svc.num}
                  </span>
                  <h3 style={{
                    fontSize: 'clamp(22px, 2.5vw, 36px)',
                    fontWeight: 500,
                    fontFamily: "'Overused Grotesk', Arial, sans-serif",
                    color: open === i ? '#c9a84c' : '#f0ead6',
                    transition: 'color 0.3s ease',
                    lineHeight: 1.2,
                  }}>
                    {svc.title}
                  </h3>
                </div>
                <span style={{
                  fontSize: '28px',
                  fontWeight: 300,
                  color: '#c9a84c',
                  flexShrink: 0,
                  transition: 'transform 0.3s ease',
                  transform: open === i ? 'rotate(45deg)' : 'rotate(0deg)',
                  lineHeight: 1,
                }}>
                  +
                </span>
              </button>

              <div
                style={{
                  maxHeight: open === i ? '300px' : '0',
                  overflow: 'hidden',
                  transition: 'max-height 0.5s cubic-bezier(0.04, 0.62, 0.23, 0.98)',
                }}
              >
                <p style={{
                  paddingBottom: '32px',
                  paddingLeft: '56px',
                  fontSize: 'clamp(16px, 1.4vw, 20px)',
                  lineHeight: 1.75,
                  color: 'rgba(240,234,214,0.65)',
                  fontFamily: "'Overused Grotesk', Arial, sans-serif",
                  fontWeight: 400,
                  maxWidth: '680px',
                }}>
                  {svc.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
