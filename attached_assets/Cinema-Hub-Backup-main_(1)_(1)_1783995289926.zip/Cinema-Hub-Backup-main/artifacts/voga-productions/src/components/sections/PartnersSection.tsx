import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const partners = [
  { name: 'ORIENTICA', img: 'https://res.cloudinary.com/dzkhuidmn/image/upload/q_auto,f_auto/v1781411219/new_logo_rb0j3q.png' },
  { name: 'NAYAAT', img: 'https://res.cloudinary.com/dzkhuidmn/image/upload/q_auto,f_auto/v1781411289/IMG_4266_gaap0b.jpg' },
  { name: 'BRIGHT INTERIOR', img: 'https://res.cloudinary.com/dzkhuidmn/image/upload/q_auto,f_auto/v1781411316/bright_interior_logo_final_naqxyw.png' },
  { name: 'GOLTENS', img: 'https://res.cloudinary.com/dzkhuidmn/image/upload/q_auto,f_auto/v1781411340/goltens-logo-vector_efdptb.png' },
  { name: 'ELITE LUXURY', img: 'https://res.cloudinary.com/dzkhuidmn/image/upload/q_auto,f_auto/v1781411359/ELITE_Logo-1_h2lftj.webp' },
  { name: 'CARAT+', img: 'https://res.cloudinary.com/dzkhuidmn/image/upload/q_auto,f_auto/v1781411378/carat_logo_lf5ikr.png' },
];

const TRACK = [...partners, ...partners, ...partners];

export default function PartnersSection() {
  const labelRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    gsap.fromTo(labelRef.current,
      { opacity: 0, y: 16 },
      { opacity: 1, y: 0, duration: 0.9, ease: 'power3.out', scrollTrigger: { trigger: labelRef.current, start: 'top 88%' } }
    );
  }, []);

  return (
    <section style={{ padding: '80px 0', background: '#0a0a0a', borderTop: '1px solid rgba(240,234,214,0.06)', borderBottom: '1px solid rgba(240,234,214,0.06)', overflow: 'hidden' }}>
      {/* Label */}
      <div style={{ textAlign: 'center', marginBottom: '52px' }}>
        <span ref={labelRef} style={{ fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: '#c9a84c', fontFamily: "'Overused Grotesk', Arial, sans-serif" }}>
          Our Valued Partners
        </span>
      </div>

      {/* Infinite ticker */}
      <div style={{ overflow: 'hidden', position: 'relative' }}>
        <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '100px', background: 'linear-gradient(to right, #0a0a0a, transparent)', zIndex: 2, pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: '100px', background: 'linear-gradient(to left, #0a0a0a, transparent)', zIndex: 2, pointerEvents: 'none' }} />

        <div className="ticker-track" style={{ display: 'flex', alignItems: 'center', width: 'max-content' }}>
          {TRACK.map((p, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '14px', padding: '0 48px', flexShrink: 0, borderRight: '1px solid rgba(240,234,214,0.08)' }}>
              <img
                src={p.img}
                alt={p.name}
                style={{ height: '32px', width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)', opacity: 0.5 }}
                onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
              />
              <span style={{ fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(240,234,214,0.38)', fontFamily: "'Overused Grotesk', Arial, sans-serif", whiteSpace: 'nowrap' }}>
                {p.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
